class Configurations {
  static const _apiKey = "AIzaSyBSOtIHg29s2oYDo7IrmWP5L2WkrDfnut0";

  static const _projectId = "ecomerceappflutter";

  static const _messagingSenderId ="189075726098";
  static const _appId = "1:189075726098:android:f11856201255db4abeddcbs";

//Make some getter functions
  String get apiKey => _apiKey;

  String get projectId => _projectId;

  String get messagingSenderId => _messagingSenderId;
  String get appId => _appId;
}