import 'package:ecomerce_app_using_provider/utilis/utilis.dart';
import 'package:ecomerce_app_using_provider/view/auth/verify_code.dart';
import 'package:ecomerce_app_using_provider/view/widget/round_button.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

class LoginWithPhone extends StatefulWidget {
  const LoginWithPhone({super.key});

  @override
  State<LoginWithPhone> createState() => _LoginWithPhoneState();
}

class _LoginWithPhoneState extends State<LoginWithPhone> {
  TextEditingController phoneController=TextEditingController();
  final  auth=FirebaseAuth.instance;
  bool loading=false;
  @override
  Widget build(BuildContext context) {
    return  Scaffold(
      appBar: AppBar(
        title: Text('Login With Phone No'),
      ),
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 20.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            SizedBox(height: 50,),
            TextFormField(
              controller: phoneController,

              decoration: InputDecoration(
                hintText: '+92 3327332894',
                border: OutlineInputBorder( // Border style
                  borderRadius: BorderRadius.circular(10.0),
                ),
                focusedBorder: OutlineInputBorder( // Border style when the field is focused
                  borderRadius: BorderRadius.circular(10.0),
                  borderSide: BorderSide(color: Colors.blue),
                ),
            )
            ),
            SizedBox(height: 50,),
            RoundButton(title: 'Add Phone No', onTap: (){
              auth.verifyPhoneNumber(
                phoneNumber: phoneController.text,
                  verificationCompleted: (_){},
                  verificationFailed: (e){
                  Utilis().toastMessage(e.toString());
                  },
                  codeSent: (String verifiactionId,int? token){
                    Navigator.push(context,
                        MaterialPageRoute(builder: (context)=> VerifyCode(
                          verifcationId:verifiactionId ,
                        )));

                  },
                  codeAutoRetrievalTimeout:(e){
                    Utilis().toastMessage(e.toString());
                  } );

            })
          ],
        ),
      ),
    );
  }
}
