package com.example.ecomerce_app_using_provider

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
